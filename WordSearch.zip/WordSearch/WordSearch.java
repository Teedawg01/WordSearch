
public class WordSearch {

	public static void main(String[] args) {
		
		char[][] board = {
				{'A', 'B', 'C', 'E'},
				{'S', 'F', 'C', 'S'},
				{'A', 'D', 'E', 'E'}
				
		};
		String word = "ABCCED";
		String word1 = "SEE";
		String word2 = "ABCB";
		
		
		Search search = new Search();
		

		System.out.println("Example 1: Word = \"ABCCED\", Result =  " + search.Exist(board, word));
		System.out.println("Example 2: Word = \"SEE\", Result =  " + search.Exist(board, word1));
		System.out.println("Example 3: Word = \"ABCB\", Result =  " + search.Exist(board, word2));
		

	}

}
